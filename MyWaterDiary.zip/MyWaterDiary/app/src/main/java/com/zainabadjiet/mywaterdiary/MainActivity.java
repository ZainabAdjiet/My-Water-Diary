package com.zainabadjiet.mywaterdiary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mainRecycler;
    private RecyclerView.Adapter mainAdapter;
    private RecyclerView.LayoutManager mainLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainRecycler = (RecyclerView) findViewById(R.id.main_recycler);
        mainRecycler.setHasFixedSize(true);

        mainLayoutManager = new LinearLayoutManager(this);
        mainRecycler.setLayoutManager(mainLayoutManager);
    }
}
